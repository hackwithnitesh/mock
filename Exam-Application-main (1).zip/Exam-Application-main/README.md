#Quiz Application
___
Open source Web Application for conducting online exam.

to start the application clone to your local computer and install the following dependencys .
```
npn install @hapi/joi bcrypt body-parser cookie-parser cors     dotenv express jsonwebtoken mongoose
```
To run the program 
~~~
npm start
~~~

#Technology used

1.HTML,CSS,JS(styling)

2.NodeJs(backend language)

3.mongoDB(Database)
